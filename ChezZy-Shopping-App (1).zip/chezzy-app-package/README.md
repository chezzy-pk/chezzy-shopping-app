# ChezZy Online Shopping App

A complete mobile-responsive shopping application built with Flask and modern web technologies.

## Features

- **Login/Registration Page** - Beautiful onboarding with custom illustrations
- **Shopping Homepage** - Product grid with search and categories
- **Product Details** - Individual product pages with full information
- **Services Page** - 6 service cards with yellow/black theme
- **About Page** - Company information
- **Mobile-First Design** - Optimized for mobile devices
- **Yellow Color Theme** - Modern and attractive UI

## Installation

1. Install Python 3.11+
2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the application:
```bash
python main.py
```

4. Open browser to `http://localhost:5000`

## File Structure

```
chezzy-app-package/
├── templates/          # HTML templates
│   ├── base.html      # Base template
│   ├── login.html     # Login/signup page
│   ├── index.html     # Shopping homepage
│   ├── product_detail.html
│   ├── services.html  # Services page
│   └── about.html     # About page
├── static/
│   ├── css/
│   │   └── style.css  # All styles
│   └── js/
│       └── main.js    # JavaScript functionality
├── data/
│   └── products.json  # Product data
├── app.py             # Flask app configuration
├── main.py            # Application entry point
├── routes.py          # URL routes and logic
└── pyproject.toml     # Dependencies
```

## Pages

1. **Login Page (/)** - First page users see
2. **Home Page (/home)** - Main shopping interface
3. **Product Detail (/product/<id>)** - Individual product pages
4. **Services (/services)** - Service offerings
5. **About (/about)** - Company information

## Navigation

Three-button bottom navigation:
- **Home** - Main shopping page
- **Services** - Special styled service button
- **About** - Company info

## Technologies Used

- Flask (Python web framework)
- HTML5/CSS3
- JavaScript
- Bootstrap 5
- Font Awesome icons
- Custom SVG illustrations

## Color Scheme

- Primary: Yellow (#eab308)
- Secondary: Dark Blue (#1e293b)
- Background: Light Gray (#f8fafc)
- Text: Dark (#1e293b)

## Created By

Villan Aqib Khan
Sarghoda Beautiful Store