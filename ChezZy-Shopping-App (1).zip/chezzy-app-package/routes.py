import json
import os
from flask import render_template, request, jsonify, redirect
from app import app

def load_products():
    """Load products from JSON file"""
    try:
        with open('data/products.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

@app.route('/')
def index():
    """Login page - first page users see"""
    return render_template('login.html')

@app.route('/home')
def home():
    """Main shop page"""
    products = load_products()
    return render_template('index.html', products=products)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    """Product detail page"""
    products = load_products()
    product = next((p for p in products if p['id'] == product_id), None)
    if product:
        return render_template('product_detail.html', product=product)
    return "Product not found", 404

@app.route('/search')
def search():
    """Search functionality"""
    query = request.args.get('q', '')
    products = load_products()
    
    if query:
        # Simple search by name and description
        filtered_products = [
            p for p in products 
            if query.lower() in p['name'].lower() or query.lower() in p['description'].lower()
        ]
    else:
        filtered_products = products
    
    return render_template('index.html', products=filtered_products, search_query=query)

@app.route('/category/<category>')
def category_filter(category):
    """Filter products by category"""
    products = load_products()
    # For now, just return all products regardless of category
    # In a real app, you'd filter by category
    return render_template('index.html', products=products, active_category=category)

@app.route('/services')
def services():
    """Services page"""
    return render_template('services.html')

@app.route('/about')
def about():
    """About page"""
    return render_template('about.html')

@app.route('/register', methods=['POST'])
def register():
    """Handle registration"""
    # For now, just redirect to home page
    return redirect('/home')

@app.route('/existing-login')
def existing_login():
    """Login page for existing users"""
    return redirect('/home')
